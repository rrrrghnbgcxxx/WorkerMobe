# Build the JAR using only your phone

The easiest phone-only route is GitHub Actions. ZArchiver cannot compile Java/NeoForge by itself.

1. Create a GitHub account (or use an existing one).
2. Create a new repository, for example `WorkerMob`.
3. Extract this ZIP with ZArchiver.
4. Upload the **contents** of the extracted folder to the GitHub repository. Do not upload the ZIP as the only file.
   You should see `build.gradle`, `gradle.properties`, `settings.gradle`, `src`, and `.github` in the repository.
5. Open the repository's **Actions** tab.
6. Select **Build Worker Mob**.
7. Press **Run workflow**.
8. Wait for the build to finish.
9. Open the completed workflow run and find **Artifacts**.
10. Download `workermob-jar`.
11. Inside the downloaded artifact is the real `workermob-1.1.0.jar`.
12. In your Android Minecraft/NeoForge 1.21.1 instance, put that JAR in its `mods` folder.

NeoForge 1.21.1 requires Java 21. The GitHub Actions workflow installs Java 21 automatically.

Important: do NOT rename the source ZIP to `.jar`. A JAR is produced by Gradle during the build.
