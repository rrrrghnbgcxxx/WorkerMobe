# Worker Mob — NeoForge 1.21.1

A worker NPC mod project for Minecraft 1.21.1.

Features implemented:
- 50 HP
- fast movement
- automatic mature crop harvesting
- wheat/carrot/potato/beetroot replanting
- bone meal use
- nearby chest deposit
- 27-slot worker inventory
- crouch + right-click opens inventory
- normal right-click toggles sit/work mode
- food consumption to heal
- sword-based hostile mob targeting
- ignores passive mobs for its normal combat target
- worker spawn egg
- crafting recipe: two dirt on the left of an iron ingot
- persistence

Build:
`gradle build`

Phone-only build:
See `PHONE_BUILD.md`. The included `.github/workflows/build.yml` builds the actual JAR with Java 21.

The custom skin/texture is still a separate asset: replace
`src/main/resources/assets/workermob/textures/entity/worker.png`
with a 64x64 PNG Minecraft skin/texture and adjust the renderer/model if a custom model is desired.
