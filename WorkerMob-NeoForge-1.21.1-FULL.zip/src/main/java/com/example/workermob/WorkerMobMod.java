package com.example.workermob;

import com.example.workermob.entity.ModEntities;
import com.example.workermob.entity.WorkerMob;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;

@Mod(WorkerMobMod.MOD_ID)
public class WorkerMobMod {

    public static final String MOD_ID = "workermob";

    public WorkerMobMod(IEventBus modBus) {
        ModEntities.ENTITY_TYPES.register(modBus);
        ModEntities.ITEMS.register(modBus);

        modBus.addListener(this::registerAttributes);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(
                ModEntities.WORKER_MOB.get(),
                WorkerMob.createAttributes().build()
        );
    }
}
