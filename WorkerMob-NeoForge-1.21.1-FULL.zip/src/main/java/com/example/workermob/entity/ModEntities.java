package com.example.workermob.entity;

import com.example.workermob.WorkerMobMod;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public final class ModEntities {
    private ModEntities() {}

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(BuiltInRegistries.ENTITY_TYPE, WorkerMobMod.MOD_ID);

    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(WorkerMobMod.MOD_ID);

    public static final Supplier<EntityType<WorkerMob>> WORKER_MOB =
            ENTITY_TYPES.register("worker", () ->
                    EntityType.Builder.of(WorkerMob::new, MobCategory.CREATURE)
                            .sized(0.6F, 1.95F)
                            .clientTrackingRange(8)
                            .updateInterval(3)
                            .build("workermob:worker")
            );

    public static final Supplier<Item> WORKER_SPAWN_EGG =
            ITEMS.registerItem(
                    "worker_spawn_egg",
                    props -> new SpawnEggItem(WORKER_MOB.get(), 0x6B4F3A, 0xD7B98E, props)
            );
}
