package com.example.workermob.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.common.NeoForge;

import java.util.*;

public class WorkerMob extends PathfinderMob {
    private final SimpleContainer workerInventory = new SimpleContainer(27);
    private boolean sitting = false;
    private int workCooldown = 0;
    private int healCooldown = 0;

    public WorkerMob(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 0;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 50.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.34D)
                .add(Attributes.ATTACK_DAMAGE, 5.0D)
                .add(Attributes.ATTACK_SPEED, 1.2D)
                .add(Attributes.FOLLOW_RANGE, 24.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.2D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.25D, true));
        this.goalSelector.addGoal(2, new RandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(
                this, Monster.class, true,
                monster -> hasSword()
        ));
    }

    public boolean hasSword() {
        for (int i = 0; i < workerInventory.getContainerSize(); i++) {
            if (workerInventory.getItem(i).getItem() instanceof SwordItem) return true;
        }
        return false;
    }

    private int findItem(Item item) {
        for (int i = 0; i < workerInventory.getContainerSize(); i++) {
            if (workerInventory.getItem(i).is(item)) return i;
        }
        return -1;
    }

    private int findFood() {
        for (int i = 0; i < workerInventory.getContainerSize(); i++) {
            ItemStack stack = workerInventory.getItem(i);
            if (stack.isEdible()) return i;
        }
        return -1;
    }

    private int findSword() {
        for (int i = 0; i < workerInventory.getContainerSize(); i++) {
            if (workerInventory.getItem(i).getItem() instanceof SwordItem) return i;
        }
        return -1;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || sitting) return;

        if (healCooldown > 0) healCooldown--;
        if (workCooldown > 0) workCooldown--;

        // Keep a sword equipped when available so normal melee AI can use it.
        int sword = findSword();
        if (sword >= 0 && getMainHandItem().isEmpty()) {
            setItemInHand(InteractionHand.MAIN_HAND, workerInventory.removeItem(sword, 1));
        }

        // Eat food when hurt.
        if (getHealth() < getMaxHealth() && healCooldown == 0) {
            int foodSlot = findFood();
            if (foodSlot >= 0) {
                ItemStack food = workerInventory.getItem(foodSlot);
                food.shrink(1);
                heal(4.0F);
                healCooldown = 60;
            }
        }

        // Pick up nearby drops.
        AABB pickupBox = getBoundingBox().inflate(3.0D);
        for (ItemEntity item : level().getEntitiesOfClass(ItemEntity.class, pickupBox)) {
            ItemStack stack = item.getItem().copy();
            if (insertIntoInventory(stack)) item.discard();
        }

        if (workCooldown == 0) {
            workCooldown = 10;
            doFarmWork();
        }
    }

    private boolean insertIntoInventory(ItemStack stack) {
        ItemStack remaining = stack.copy();
        for (int i = 0; i < workerInventory.getContainerSize(); i++) {
            ItemStack slot = workerInventory.getItem(i);
            if (slot.isEmpty()) {
                workerInventory.setItem(i, remaining.copy());
                return true;
            }
            if (ItemStack.isSameItemSameComponents(slot, remaining) && slot.getCount() < slot.getMaxStackSize()) {
                int move = Math.min(remaining.getCount(), slot.getMaxStackSize() - slot.getCount());
                slot.grow(move);
                remaining.shrink(move);
                if (remaining.isEmpty()) return true;
            }
        }
        return remaining.isEmpty();
    }

    private boolean hasPlantableFor(BlockState state) {
        if (state.is(Blocks.WHEAT)) return findItem(Items.WHEAT_SEEDS) >= 0;
        if (state.is(Blocks.CARROTS)) return findItem(Items.CARROT) >= 0;
        if (state.is(Blocks.POTATOES)) return findItem(Items.POTATO) >= 0;
        if (state.is(Blocks.BEETROOTS)) return findItem(Items.BEETROOT_SEEDS) >= 0;
        return false;
    }

    private Item plantItem(BlockState state) {
        if (state.is(Blocks.WHEAT)) return Items.WHEAT_SEEDS;
        if (state.is(Blocks.CARROTS)) return Items.CARROT;
        if (state.is(Blocks.POTATOES)) return Items.POTATO;
        if (state.is(Blocks.BEETROOTS)) return Items.BEETROOT_SEEDS;
        return Items.AIR;
    }

    private void doFarmWork() {
        BlockPos center = blockPosition();
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();

        // Search a compact working area around the worker.
        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                for (int dy = -1; dy <= 1; dy++) {
                    cursor.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    BlockState state = level().getBlockState(cursor);

                    if (state.getBlock() instanceof CropBlock crop) {
                        if (crop.isMaxAge(state)) {
                            // Harvest. Vanilla block drops become nearby ItemEntity objects,
                            // which the worker picks up on subsequent ticks.
                            level().destroyBlock(cursor, true, this);
                            if (hasPlantableFor(state)) {
                                Item seed = plantItem(state);
                                int slot = findItem(seed);
                                if (slot >= 0) {
                                    ItemStack stack = workerInventory.getItem(slot);
                                    stack.shrink(1);
                                    level().setBlock(cursor, crop.defaultBlockState(), 3);
                                }
                            }
                            useBonemealNearby(cursor);
                            depositToNearbyChest();
                            return;
                        }
                    }
                }
            }
        }

        // Replant empty farmland and use bonemeal where possible.
        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -6; dz <= 6; dz++) {
                cursor.set(center.getX() + dx, center.getY(), center.getZ() + dz);
                if (level().getBlockState(cursor).is(Blocks.FARMLAND)
                        && level().getBlockState(cursor.above()).isAir()) {
                    if (plantCrop(cursor.above())) {
                        useBonemealNearby(cursor.above());
                        depositToNearbyChest();
                        return;
                    }
                }
            }
        }
    }

    private boolean plantCrop(BlockPos pos) {
        if (!level().getBlockState(pos).isAir()) return false;
        if (findItem(Items.WHEAT_SEEDS) >= 0) {
            workerInventory.getItem(findItem(Items.WHEAT_SEEDS)).shrink(1);
            level().setBlock(pos, Blocks.WHEAT.defaultBlockState(), 3);
            return true;
        }
        if (findItem(Items.CARROT) >= 0) {
            workerInventory.getItem(findItem(Items.CARROT)).shrink(1);
            level().setBlock(pos, Blocks.CARROTS.defaultBlockState(), 3);
            return true;
        }
        if (findItem(Items.POTATO) >= 0) {
            workerInventory.getItem(findItem(Items.POTATO)).shrink(1);
            level().setBlock(pos, Blocks.POTATOES.defaultBlockState(), 3);
            return true;
        }
        if (findItem(Items.BEETROOT_SEEDS) >= 0) {
            workerInventory.getItem(findItem(Items.BEETROOT_SEEDS)).shrink(1);
            level().setBlock(pos, Blocks.BEETROOTS.defaultBlockState(), 3);
            return true;
        }
        return false;
    }

    private void useBonemealNearby(BlockPos cropPos) {
        int slot = findItem(Items.BONE_MEAL);
        if (slot < 0) return;
        BlockState state = level().getBlockState(cropPos);
        if (state.getBlock() instanceof BonemealableBlock bonemealable && bonemealable.isValidBonemealTarget(level(), cropPos, state)) {
            bonemealable.performBonemeal((ServerLevel) level(), level().random, cropPos, state);
            workerInventory.getItem(slot).shrink(1);
        }
    }

    private void depositToNearbyChest() {
        if (!(level() instanceof ServerLevel server)) return;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        BlockPos base = blockPosition();

        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                p.set(base.getX() + dx, base.getY(), base.getZ() + dz);
                BlockEntity be = level().getBlockEntity(p);
                if (be instanceof ChestBlockEntity chest) {
                    for (int i = 0; i < workerInventory.getContainerSize(); i++) {
                        ItemStack stack = workerInventory.getItem(i);
                        if (stack.isEmpty()) continue;
                        ItemStack copy = stack.copy();
                        for (int j = 0; j < chest.getContainerSize() && !copy.isEmpty(); j++) {
                            ItemStack inChest = chest.getItem(j);
                            if (inChest.isEmpty()) {
                                chest.setItem(j, copy.copy());
                                copy.setCount(0);
                            } else if (ItemStack.isSameItemSameComponents(inChest, copy)
                                    && inChest.getCount() < inChest.getMaxStackSize()) {
                                int move = Math.min(copy.getCount(), inChest.getMaxStackSize() - inChest.getCount());
                                inChest.grow(move);
                                copy.shrink(move);
                            }
                        }
                        stack.setCount(copy.getCount());
                    }
                    chest.setChanged();
                    return;
                }
            }
        }
    }

    public SimpleContainer getWorkerInventory() {
        return workerInventory;
    }

    public boolean isSitting() {
        return sitting;
    }

    private void setSitting(boolean value) {
        sitting = value;
        getNavigation().stop();
        setTarget(null);
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);

        if (player.isShiftKeyDown() && !level().isClientSide) {
            player.openMenu(new net.minecraft.world.SimpleMenuProvider(
                    (id, inv, p) -> ChestMenu.threeRows(
                            id, inv, workerInventory),
                    Component.literal("Worker Inventory")
            ));
            return InteractionResult.CONSUME;
        }

        if (!level().isClientSide) {
            setSitting(!sitting);
            player.displayClientMessage(
                    Component.literal(sitting ? "Worker is sitting." : "Worker is working."),
                    true
            );
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
        boolean result = super.hurt(source, amount);
        if (result && source.getEntity() instanceof LivingEntity attacker && attacker != this) {
            setTarget(attacker);
        }
        return result;
    }
}
